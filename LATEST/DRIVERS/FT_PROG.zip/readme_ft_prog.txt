
					****************************************************
					**                     README                     **
					****************************************************

To run the FT_PROG application.

1. Follow the instructions on the FTDI website for installing the latest version of the D2XX drivers (required to run the application).
		http://www.ftdichip.com/Support/Knowledgebase/index.html?98installingd2xxdrivers2.htm

2. Download the latest version of FT_PROG from the Utilites section of the FTDI website.
		http://www.ftdichip.com/Resources/Utilities.htm

3. Unzip all files from the .zip folder that you have downloaded.

4. FT_PROG requires Microsoft .NET Framework 2.0 installed on your system to run.  This can be obtained from the Microsoft website: http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=en 
Download and follow the wizard for installing .NET 2.0 if you do not have this already installed on your system. 

5. To run the application double click on the FT_PROG.exe icon.
