FPGA 25042017 ge�ndert auf KEINEN Pullup an MIDI IN 2
 
HX3 mk2 und mk3 boards weiterhin mit FPGA 24042017 programmieren!

-cm