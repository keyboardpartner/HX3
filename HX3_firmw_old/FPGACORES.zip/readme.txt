FPGA Configuration files
========================

Please note: There are two FPGA configuration files to choose from:

FPGA_27092013	slightly thin sound on higher notes, low "plop" noise
FPGA_09122013 fatter sound on higher notes, somewhat higher "plop" noise

Default is now FPGA_09122013. Please copy appropriate file to FPGACORES directory. 

Scan cores revision #0B require AVR firmware #3.41 and up.

